pub const module_name: [:0]const u8 = "example.result_types";
pub const limited_api: bool = true;
pub const hexversion: []const u8 = "0x030d03f0";
