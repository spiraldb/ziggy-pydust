pub const module_name: [:0]const u8 = "example.classes";
pub const limited_api: bool = true;
pub const hexversion: []const u8 = "0x030d03f0";
